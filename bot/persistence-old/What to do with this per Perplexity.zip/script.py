# Create the facade layer files that will be placed in the bot/persistence folder

facade_files = {}

# 1. Core facade interface
facade_files['__init__.py'] = '''"""
GOF2BountyBot Storage Facade Layer

This package provides a unified interface for all data storage operations
in the GOF2BountyBot system. It abstracts away the underlying storage 
mechanisms and allows for seamless migration from JSON to SQL databases.

Usage:
    from bot.persistence import StorageFacade, EntityType
    
    facade = StorageFacade()
    
    # Save a user
    result = await facade.save_user("123456789", user_data)
    
    # Get a user
    result = await facade.get_user("123456789")
    if result.success:
        user_data = result.data
"""

from .facade import StorageFacade, EntityType, StorageResult
from .repositories import Repository, JSONRepository
from .adapters import UserAdapter, GuildAdapter, BountyAdapter, ReactionMenuAdapter

__all__ = [
    'StorageFacade',
    'EntityType', 
    'StorageResult',
    'Repository',
    'JSONRepository',
    'UserAdapter',
    'GuildAdapter',
    'BountyAdapter',
    'ReactionMenuAdapter'
]
'''

# 2. Core facade implementation
facade_files['facade.py'] = '''"""
Main Storage Facade Implementation

This module contains the primary StorageFacade class that serves as the 
main entry point for all data storage operations in the bot.
"""

from __future__ import annotations
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, Optional

from .repositories import Repository, JSONRepository
from .adapters import UserAdapter, GuildAdapter, BountyAdapter, ReactionMenuAdapter


class StorageResult:
    """Represents the result of a storage operation."""
    
    def __init__(self, 
                 success: bool, 
                 data: Any = None, 
                 error: Optional[str] = None,
                 source: str = "unknown"):
        self.success = success
        self.data = data
        self.error = error
        self.source = source
    
    def __bool__(self) -> bool:
        """Allow StorageResult to be used in boolean context."""
        return self.success


class EntityType(Enum):
    """Enum representing the different types of entities in the system."""
    USER = auto()
    GUILD = auto()
    BOUNTY = auto()
    REACTION_MENU = auto()
    GAME_DATA = auto()


class StorageFacade:
    """Main entry point for all data storage operations.
    
    This class provides a unified interface for all data storage operations,
    regardless of the underlying storage mechanism.
    """
    
    def __init__(self, data_dir: str = "data"):
        """Initialize a new StorageFacade.
        
        Args:
            data_dir: Directory where data files are stored
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize repositories for each entity type
        self._repositories: Dict[EntityType, Repository] = {
            EntityType.USER: JSONRepository(self.data_dir / "users.json"),
            EntityType.GUILD: JSONRepository(self.data_dir / "guilds.json"),
            EntityType.BOUNTY: JSONRepository(self.data_dir / "bounties.json"),
            EntityType.REACTION_MENU: JSONRepository(self.data_dir / "reaction_menus.json"),
            EntityType.GAME_DATA: JSONRepository(self.data_dir / "game_data.json")
        }
        
        # Initialize adapters for high-level operations
        self.users = UserAdapter(self._repositories[EntityType.USER])
        self.guilds = GuildAdapter(self._repositories[EntityType.GUILD])
        self.bounties = BountyAdapter(self._repositories[EntityType.BOUNTY])
        self.reaction_menus = ReactionMenuAdapter(self._repositories[EntityType.REACTION_MENU])
    
    def get_repository(self, entity_type: EntityType) -> Repository:
        """Get the repository for a specific entity type."""
        return self._repositories[entity_type]
    
    async def get_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID."""
        return await self.get_repository(entity_type).get(entity_id)
    
    async def get_all_entities(self, entity_type: EntityType) -> StorageResult:
        """Retrieve all entities of a specific type."""
        return await self.get_repository(entity_type).get_all()
    
    async def save_entity(self, entity_type: EntityType, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity."""
        return await self.get_repository(entity_type).save(entity_id, data)
    
    async def delete_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Delete an entity."""
        return await self.get_repository(entity_type).delete(entity_id)
    
    async def entity_exists(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Check if an entity exists."""
        return await self.get_repository(entity_type).exists(entity_id)
    
    # Convenience methods for specific entity types
    async def get_user(self, user_id: str) -> StorageResult:
        """Get a user by ID."""
        return await self.users.get_user(user_id)
    
    async def save_user(self, user_id: str, user_data: Dict[str, Any]) -> StorageResult:
        """Save user data."""
        return await self.users.save_user(user_id, user_data)
    
    async def get_guild(self, guild_id: str) -> StorageResult:
        """Get a guild by ID."""
        return await self.guilds.get_guild(guild_id)
    
    async def save_guild(self, guild_id: str, guild_data: Dict[str, Any]) -> StorageResult:
        """Save guild data."""
        return await self.guilds.save_guild(guild_id, guild_data)
    
    async def get_bounty(self, bounty_id: str) -> StorageResult:
        """Get a bounty by ID."""
        return await self.bounties.get_bounty(bounty_id)
    
    async def save_bounty(self, bounty_id: str, bounty_data: Dict[str, Any]) -> StorageResult:
        """Save bounty data."""
        return await self.bounties.save_bounty(bounty_id, bounty_data)
'''

# 3. Repository interfaces and implementations
facade_files['repositories.py'] = '''"""
Repository Interface and Implementations

This module contains the abstract Repository interface and concrete implementations
for different storage backends (JSON, SQL, etc.).
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Generic, TypeVar, Union
import json
import logging
import aiofiles

from .facade import StorageResult

# Set up logging
logger = logging.getLogger('storage_facade')

# Generic type variable for entities
T = TypeVar('T')


class Repository(Generic[T], ABC):
    """Base interface for all repositories.
    
    A repository is responsible for storing and retrieving entities of a specific type.
    """
    
    @abstractmethod
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID."""
        pass
    
    @abstractmethod
    async def get_all(self) -> StorageResult:
        """Retrieve all entities in the repository."""
        pass
    
    @abstractmethod
    async def save(self, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the repository."""
        pass
    
    @abstractmethod
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the repository."""
        pass
    
    @abstractmethod
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the repository."""
        pass


class JSONRepository(Repository[T]):
    """JSON file implementation of Repository.
    
    This class implements the Repository interface using JSON files as the storage mechanism.
    """
    
    def __init__(self, file_path: Union[str, Path]):
        """Initialize a new JSONRepository."""
        self.file_path = Path(file_path)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        
    async def _load_data(self) -> Dict[str, Any]:
        """Load data from the JSON file."""
        if not self.file_path.exists():
            return {}
        
        try:
            async with aiofiles.open(self.file_path, 'r') as f:
                content = await f.read()
                return json.loads(content) if content.strip() else {}
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading JSON from {self.file_path}: {e}")
            return {}
    
    async def _save_data(self, data: Dict[str, Any]) -> bool:
        """Save data to the JSON file."""
        try:
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            
            async with aiofiles.open(self.file_path, 'w') as f:
                await f.write(json.dumps(data, indent=2))
            
            return True
        except IOError as e:
            logger.error(f"Error saving to JSON {self.file_path}: {e}")
            return False
    
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID from the JSON file."""
        data = await self._load_data()
        
        if entity_id in data:
            return StorageResult(
                success=True,
                data=data[entity_id],
                source="json"
            )
        
        return StorageResult(
            success=False,
            error=f"Entity {entity_id} not found",
            source="json"
        )
    
    async def get_all(self) -> StorageResult:
        """Retrieve all entities from the JSON file."""
        data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=list(data.values()),
            source="json"
        )
    
    async def save(self, entity_id: str, entity_data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the JSON file."""
        all_data = await self._load_data()
        
        # Ensure ID is set in data
        entity_data = entity_data.copy()  # Don't modify the original
        entity_data["id"] = entity_id
        
        # Update with new data
        all_data[entity_id] = entity_data
        
        # Save back to file
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                data=entity_data,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON",
            source="json"
        )
    
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the JSON file."""
        all_data = await self._load_data()
        
        if entity_id not in all_data:
            return StorageResult(
                success=False,
                error=f"Entity {entity_id} not found",
                source="json"
            )
        
        del all_data[entity_id]
        
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON after deletion",
            source="json"
        )
    
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the JSON file."""
        all_data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=entity_id in all_data,
            source="json"
        )
'''

# 4. High-level adapters for specific entity types
facade_files['adapters.py'] = '''"""
High-level adapters for specific entity types

These adapters provide entity-specific methods that build on top of the base repository interface.
They implement the business logic and provide convenience methods for working with specific entities.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional

from .facade import StorageResult
from .repositories import Repository


class BaseAdapter:
    """Base class for all adapters."""
    
    def __init__(self, repository: Repository):
        self.repository = repository


class UserAdapter(BaseAdapter):
    """Adapter for user entities.
    
    Provides user-specific operations like credit management, inventory operations, etc.
    """
    
    async def get_user(self, user_id: str) -> StorageResult:
        """Get a user by ID."""
        return await self.repository.get(user_id)
    
    async def save_user(self, user_id: str, user_data: Dict[str, Any]) -> StorageResult:
        """Save user data."""
        return await self.repository.save(user_id, user_data)
    
    async def create_user(self, user_id: str, username: Optional[str] = None) -> StorageResult:
        """Create a new user with default values."""
        default_user = {
            "id": user_id,
            "username": username,
            "credits": 0,
            "reputation": 0,
            "inventory": {},
            "settings": {},
            "lifetimeBountyCreditsWon": 0,
            "bountyCooldownEnd": -1.0,
            "systemsChecked": 0,
            "bountyWins": 0,
            "duelWins": 0,
            "duelLosses": 0,
            "duelCreditsWins": 0,
            "duelCreditsLosses": 0,
            "homeGuildID": -1,
            "prestiges": 0,
            "alerts": {},
            "classicModeEnabled": False
        }
        
        return await self.repository.save(user_id, default_user)
    
    async def get_or_create_user(self, user_id: str, username: Optional[str] = None) -> StorageResult:
        """Get a user or create it if it doesn't exist."""
        result = await self.get_user(user_id)
        
        if result.success:
            return result
        
        # User doesn't exist, create it
        return await self.create_user(user_id, username)
    
    async def update_user_credits(self, user_id: str, amount: int) -> StorageResult:
        """Update user credits by the specified amount."""
        result = await self.get_or_create_user(user_id)
        
        if not result.success:
            return result
        
        user_data = result.data
        user_data["credits"] = user_data.get("credits", 0) + amount
        
        return await self.save_user(user_id, user_data)
    
    async def get_user_credits(self, user_id: str) -> StorageResult:
        """Get user credits (returns 0 if user doesn't exist)."""
        result = await self.get_user(user_id)
        
        if result.success:
            credits = result.data.get("credits", 0)
            return StorageResult(success=True, data=credits, source=result.source)
        
        return StorageResult(success=True, data=0, source="default")
    
    async def set_user_home_guild(self, user_id: str, guild_id: str) -> StorageResult:
        """Set the user's home guild."""
        result = await self.get_or_create_user(user_id)
        
        if not result.success:
            return result
        
        user_data = result.data
        user_data["homeGuildID"] = int(guild_id) if guild_id.isdigit() else guild_id
        
        return await self.save_user(user_id, user_data)


class GuildAdapter(BaseAdapter):
    """Adapter for guild entities.
    
    Provides guild-specific operations like channel management, settings, etc.
    """
    
    async def get_guild(self, guild_id: str) -> StorageResult:
        """Get a guild by ID."""
        return await self.repository.get(guild_id)
    
    async def save_guild(self, guild_id: str, guild_data: Dict[str, Any]) -> StorageResult:
        """Save guild data."""
        return await self.repository.save(guild_id, guild_data)
    
    async def create_guild(self, guild_id: str, name: str) -> StorageResult:
        """Create a new guild with default settings."""
        default_guild = {
            "id": guild_id,
            "name": name,
            "settings": {},
            "prefix": "!",
            "enabled_modules": [],
            "admin_roles": [],
            "bountiesDisabled": False,
            "shopsDisabled": False,
            "alertRoles": {},
            "guildChannels": {}
        }
        
        return await self.repository.save(guild_id, default_guild)
    
    async def get_or_create_guild(self, guild_id: str, name: str) -> StorageResult:
        """Get a guild or create it if it doesn't exist."""
        result = await self.get_guild(guild_id)
        
        if result.success:
            return result
        
        # Guild doesn't exist, create it
        return await self.create_guild(guild_id, name)
    
    async def set_guild_prefix(self, guild_id: str, prefix: str) -> StorageResult:
        """Set the guild's command prefix."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        guild_data["prefix"] = prefix
        
        return await self.save_guild(guild_id, guild_data)
    
    async def get_guild_prefix(self, guild_id: str) -> StorageResult:
        """Get guild prefix (returns default if guild doesn't exist)."""
        result = await self.get_guild(guild_id)
        
        if result.success:
            prefix = result.data.get("prefix", "!")
            return StorageResult(success=True, data=prefix, source=result.source)
        
        return StorageResult(success=True, data="!", source="default")
    
    async def enable_module(self, guild_id: str, module_name: str) -> StorageResult:
        """Enable a module for the guild."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        enabled_modules = guild_data.get("enabled_modules", [])
        
        if module_name not in enabled_modules:
            enabled_modules.append(module_name)
            guild_data["enabled_modules"] = enabled_modules
        
        return await self.save_guild(guild_id, guild_data)
    
    async def disable_module(self, guild_id: str, module_name: str) -> StorageResult:
        """Disable a module for the guild."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        enabled_modules = guild_data.get("enabled_modules", [])
        
        if module_name in enabled_modules:
            enabled_modules.remove(module_name)
            guild_data["enabled_modules"] = enabled_modules
        
        return await self.save_guild(guild_id, guild_data)


class BountyAdapter(BaseAdapter):
    """Adapter for bounty entities.
    
    Provides bounty-specific operations like searching, filtering, etc.
    """
    
    async def get_bounty(self, bounty_id: str) -> StorageResult:
        """Get a bounty by ID."""
        return await self.repository.get(bounty_id)
    
    async def save_bounty(self, bounty_id: str, bounty_data: Dict[str, Any]) -> StorageResult:
        """Save bounty data."""
        return await self.repository.save(bounty_id, bounty_data)
    
    async def get_open_bounties(self, guild_id: str) -> StorageResult:
        """Get all open bounties for a guild."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        open_bounties = [
            bounty for bounty in result.data
            if bounty.get("guild_id") == guild_id and bounty.get("status") == "open"
        ]
        
        return StorageResult(
            success=True,
            data=open_bounties,
            source=result.source
        )
    
    async def get_bounties_by_status(self, status: str) -> StorageResult:
        """Get all bounties with a specific status."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        filtered_bounties = [
            bounty for bounty in result.data
            if bounty.get("status") == status
        ]
        
        return StorageResult(
            success=True,
            data=filtered_bounties,
            source=result.source
        )


class ReactionMenuAdapter(BaseAdapter):
    """Adapter for reaction menu entities.
    
    Provides reaction menu-specific operations.
    """
    
    async def get_reaction_menu(self, menu_id: str) -> StorageResult:
        """Get a reaction menu by ID."""
        return await self.repository.get(menu_id)
    
    async def save_reaction_menu(self, menu_id: str, menu_data: Dict[str, Any]) -> StorageResult:
        """Save reaction menu data."""
        return await self.repository.save(menu_id, menu_data)
    
    async def get_active_menus(self) -> StorageResult:
        """Get all active reaction menus."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        active_menus = [
            menu for menu in result.data
            if menu.get("active", False)
        ]
        
        return StorageResult(
            success=True,
            data=active_menus,
            source=result.source
        )
'''

print("Created facade layer files:")
for filename in facade_files.keys():
    print(f"- {filename}")