"""
GOF2BountyBot Storage Facade Layer

This package provides a unified interface for all data storage operations
in the GOF2BountyBot system. It abstracts away the underlying storage 
mechanisms and allows for seamless migration from JSON to SQL databases.

Usage:
    from bot.persistence import StorageFacade, EntityType
    
    facade = StorageFacade()
    
    # Save a user
    result = await facade.save_user("123456789", user_data)
    
    # Get a user
    result = await facade.get_user("123456789")
    if result.success:
        user_data = result.data
"""

from .facade import StorageFacade, EntityType, StorageResult
from .repositories import Repository, JSONRepository
from .adapters import UserAdapter, GuildAdapter, BountyAdapter, ReactionMenuAdapter
from .config import StorageConfig, setup_storage_facade

__all__ = [
    'StorageFacade',
    'EntityType', 
    'StorageResult',
    'Repository',
    'JSONRepository',
    'UserAdapter',
    'GuildAdapter',
    'BountyAdapter',
    'ReactionMenuAdapter',
    'StorageConfig',
    'setup_storage_facade'
]