# GOF2BountyBot Storage Facade Integration Guide

This document provides step-by-step instructions for integrating the storage facade layer into your existing bot code.

## Step 1: Create the Facade Layer Files

Create the following files in your `bot/persistence/` folder (replacing any existing files that may conflict):

### File Structure
```
bot/
└── persistence/
    ├── __init__.py         # Package initialization and exports
    ├── facade.py           # Main StorageFacade class
    ├── repositories.py     # Repository interfaces and JSON implementation
    ├── adapters.py         # High-level adapters for specific entities
    ├── migration.py        # Data migration utilities
    └── config.py           # Configuration and setup utilities
```

## Step 2: Update botState.py

Add the storage facade to your bot state by modifying `bot/botState.py`:

```python
# Add these imports at the top
from bot.persistence import StorageFacade, setup_storage_facade
from bot.persistence.config import StorageConfig

# Add this line to initialize the facade (add after existing imports)
# This will be initialized in the bot setup
storage_facade = None

# Add a function to initialize the facade
def initialize_storage():
    """Initialize the storage facade."""
    global storage_facade
    config = StorageConfig(data_dir="data")
    storage_facade = setup_storage_facade(config)
    return storage_facade
```

## Step 3: Update the Bot Initialization

Modify `bot/bot.py` to initialize the storage facade. Add this to the `on_ready` event or your bot initialization:

```python
# In bot.py, in the on_ready function, add:
async def on_ready():
    # ... existing code ...
    
    # Initialize storage facade
    botState.initialize_storage()
    
    # Optional: Migrate existing data
    if not os.path.exists("data_migrated"):
        await migrate_existing_data()
        # Create marker file to indicate migration completed
        with open("data_migrated", "w") as f:
            f.write("Migration completed")
    
    # ... rest of existing code ...

async def migrate_existing_data():
    """Migrate existing data to facade layer format."""
    from bot.persistence.migration import DataMigrator
    
    migrator = DataMigrator(botState.storage_facade)
    results = await migrator.migrate_all()
    
    print(f"Migration results: {results}")
```

## Step 4: Create Helper Functions for Compatibility

Create a new file `bot/storage_bridge.py` to provide compatibility functions:

```python
"""
Storage Bridge Module

This module provides compatibility functions to help transition from the old
database classes to the new facade layer without breaking existing code.
"""

from typing import Any, Dict, Optional, Union
import bot.botState as botState


class UserDBBridge:
    """Bridge class to replace UserDB functionality."""
    
    @property
    def facade(self):
        return botState.storage_facade
    
    async def getUser(self, userID: int):
        """Get user data (replacement for UserDB.getUser)."""
        result = await self.facade.get_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    async def idExists(self, userID: int) -> bool:
        """Check if user exists."""
        result = await self.facade.entity_exists(self.facade.EntityType.USER, str(userID))
        return result.data if result.success else False
    
    async def addID(self, userID: int):
        """Add a new user with default values."""
        result = await self.facade.users.create_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    async def getOrAddID(self, userID: int):
        """Get user or create if it doesn't exist."""
        result = await self.facade.users.get_or_create_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    def _create_user_object(self, user_data: Dict[str, Any]):
        """Create a user object from the data."""
        # This would need to be adapted based on your actual BasedUser class
        # For now, return a simple object with the data
        class UserObject:
            def __init__(self, data):
                for key, value in data.items():
                    setattr(self, key, value)
                self.id = int(data.get('id', 0))
        
        return UserObject(user_data)


class GuildDBBridge:
    """Bridge class to replace GuildDB functionality."""
    
    @property
    def facade(self):
        return botState.storage_facade
    
    async def getGuild(self, guildID: int):
        """Get guild data."""
        result = await self.facade.get_guild(str(guildID))
        if result.success:
            return self._create_guild_object(result.data)
        return None
    
    async def idExists(self, guildID: int) -> bool:
        """Check if guild exists."""
        result = await self.facade.entity_exists(self.facade.EntityType.GUILD, str(guildID))
        return result.data if result.success else False
    
    async def addDcGuild(self, dcGuild):
        """Add a Discord guild."""
        result = await self.facade.guilds.create_guild(str(dcGuild.id), dcGuild.name)
        if result.success:
            return self._create_guild_object(result.data)
        return None
    
    def _create_guild_object(self, guild_data: Dict[str, Any]):
        """Create a guild object from the data."""
        # This would need to be adapted based on your actual BasedGuild class
        class GuildObject:
            def __init__(self, data):
                for key, value in data.items():
                    setattr(self, key, value)
                self.id = int(data.get('id', 0))
        
        return GuildObject(guild_data)


# Create global instances that can be used as drop-in replacements
usersDB = UserDBBridge()
guildsDB = GuildDBBridge()
```

## Step 5: Update Your Bot State to Use the Bridge

Modify `bot/botState.py` to include the bridge classes:

```python
# Add these imports
from bot.storage_bridge import usersDB, guildsDB

# Replace or add these to the existing botState
# If you have existing usersDB and guildsDB, replace them with these:
# usersDB = usersDB  # From storage_bridge
# guildsDB = guildsDB  # From storage_bridge
```

## Step 6: Update Command Functions

For commands that use the database, you can now use async/await syntax. Here's an example of how to update a command:

### Before (Old Way):
```python
def cmd_balance(message, args, isDM):
    """Show user's credit balance."""
    user = botState.client.usersDB.getOrAddID(message.author.id)
    credits = user.credits
    await message.reply(f"You have {credits} credits.")
```

### After (New Way):
```python
async def cmd_balance(message, args, isDM):
    """Show user's credit balance."""
    user = await botState.usersDB.getOrAddID(message.author.id)
    credits = user.credits
    await message.reply(f"You have {credits} credits.")
```

Or using the facade directly:
```python
async def cmd_balance(message, args, isDM):
    """Show user's credit balance."""
    result = await botState.storage_facade.users.get_user_credits(str(message.author.id))
    credits = result.data if result.success else 0
    await message.reply(f"You have {credits} credits.")
```

## Step 7: Updating Specific Use Cases

### User Credit Management
```python
# Old way:
user = botState.client.usersDB.getUser(user_id)
user.credits += amount

# New way:
await botState.storage_facade.users.update_user_credits(str(user_id), amount)
```

### Guild Settings
```python
# Old way:
guild = botState.client.guildsDB.getGuild(guild_id)
guild.prefix = new_prefix

# New way:
await botState.storage_facade.guilds.set_guild_prefix(str(guild_id), new_prefix)
```

### Checking if User/Guild Exists
```python
# Old way:
if botState.client.usersDB.idExists(user_id):
    # do something

# New way:
result = await botState.storage_facade.entity_exists(EntityType.USER, str(user_id))
if result.success and result.data:
    # do something
```

## Step 8: Testing the Integration

1. **Backup Your Data**: Before making any changes, backup your existing data files.

2. **Test Basic Operations**: Create a simple test script to verify the facade works:

```python
# test_facade.py
import asyncio
from bot.persistence import StorageFacade

async def test_facade():
    facade = StorageFacade("test_data")
    
    # Test user operations
    result = await facade.users.create_user("123", "TestUser")
    print(f"User creation: {result.success}")
    
    result = await facade.users.get_user("123")
    print(f"User retrieval: {result.success}, data: {result.data}")
    
    result = await facade.users.update_user_credits("123", 100)
    print(f"Credit update: {result.success}")
    
    result = await facade.users.get_user_credits("123")
    print(f"Credits: {result.data}")

if __name__ == "__main__":
    asyncio.run(test_facade())
```

3. **Gradual Migration**: Don't update all commands at once. Start with a few simple commands and gradually migrate more complex functionality.

## Step 9: Future SQL Migration

When you're ready to add PostgreSQL support:

1. Install the required dependencies:
```bash
pip install sqlalchemy asyncpg alembic
```

2. Create a new SQL repository class in `repositories.py`:
```python
class SQLRepository(Repository[T]):
    def __init__(self, db_session, table_class):
        self.db_session = db_session
        self.table_class = table_class
    
    # Implement the Repository interface using SQLAlchemy
    async def get(self, entity_id: str) -> StorageResult:
        # SQL implementation
        pass
```

3. Update the StorageFacade to use SQL repositories when available:
```python
# In facade.py
if database_available:
    self._repositories[EntityType.USER] = SQLRepository(db_session, UserTable)
else:
    self._repositories[EntityType.USER] = JSONRepository(self.data_dir / "users.json")
```

## Common Issues and Solutions

### Issue: "Module not found" errors
**Solution**: Make sure you've created all the files and the `__init__.py` file exports everything correctly.

### Issue: Async/await errors in existing sync code
**Solution**: Commands that use the facade will need to be converted to async functions. Use the bridge classes for a gradual transition.

### Issue: Data not persisting
**Solution**: Check that the data directory exists and is writable. Check the logs for any JSON write errors.

### Issue: Performance concerns
**Solution**: The JSON repositories are designed for moderate data loads. For high-performance needs, migrate to the SQL repositories.

## File Contents Summary

The facade layer consists of:
- **facade.py**: Main StorageFacade class and basic types
- **repositories.py**: Repository interface and JSON implementation  
- **adapters.py**: High-level entity-specific operations
- **migration.py**: Tools for migrating existing data
- **config.py**: Configuration management
- **storage_bridge.py**: Compatibility layer for existing code

This facade layer provides a clean separation between your bot logic and data storage, making it easy to transition from JSON files to a SQL database in the future.