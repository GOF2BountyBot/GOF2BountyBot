"""
Repository Interface and Implementations

This module contains the abstract Repository interface and concrete implementations
for different storage backends (JSON, SQL, etc.).
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Generic, TypeVar, Union
import json
import logging
import aiofiles

from .facade import StorageResult

# Set up logging
logger = logging.getLogger('storage_facade')

# Generic type variable for entities
T = TypeVar('T')


class Repository(Generic[T], ABC):
    """Base interface for all repositories.
    
    A repository is responsible for storing and retrieving entities of a specific type.
    """
    
    @abstractmethod
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID."""
        pass
    
    @abstractmethod
    async def get_all(self) -> StorageResult:
        """Retrieve all entities in the repository."""
        pass
    
    @abstractmethod
    async def save(self, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the repository."""
        pass
    
    @abstractmethod
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the repository."""
        pass
    
    @abstractmethod
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the repository."""
        pass


class JSONRepository(Repository[T]):
    """JSON file implementation of Repository.
    
    This class implements the Repository interface using JSON files as the storage mechanism.
    """
    
    def __init__(self, file_path: Union[str, Path]):
        """Initialize a new JSONRepository."""
        self.file_path = Path(file_path)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        
    async def _load_data(self) -> Dict[str, Any]:
        """Load data from the JSON file."""
        if not self.file_path.exists():
            return {}
        
        try:
            async with aiofiles.open(self.file_path, 'r') as f:
                content = await f.read()
                return json.loads(content) if content.strip() else {}
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading JSON from {self.file_path}: {e}")
            return {}
    
    async def _save_data(self, data: Dict[str, Any]) -> bool:
        """Save data to the JSON file."""
        try:
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            
            async with aiofiles.open(self.file_path, 'w') as f:
                await f.write(json.dumps(data, indent=2))
            
            return True
        except IOError as e:
            logger.error(f"Error saving to JSON {self.file_path}: {e}")
            return False
    
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID from the JSON file."""
        data = await self._load_data()
        
        if entity_id in data:
            return StorageResult(
                success=True,
                data=data[entity_id],
                source="json"
            )
        
        return StorageResult(
            success=False,
            error=f"Entity {entity_id} not found",
            source="json"
        )
    
    async def get_all(self) -> StorageResult:
        """Retrieve all entities from the JSON file."""
        data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=list(data.values()),
            source="json"
        )
    
    async def save(self, entity_id: str, entity_data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the JSON file."""
        all_data = await self._load_data()
        
        # Ensure ID is set in data
        entity_data = entity_data.copy()  # Don't modify the original
        entity_data["id"] = entity_id
        
        # Update with new data
        all_data[entity_id] = entity_data
        
        # Save back to file
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                data=entity_data,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON",
            source="json"
        )
    
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the JSON file."""
        all_data = await self._load_data()
        
        if entity_id not in all_data:
            return StorageResult(
                success=False,
                error=f"Entity {entity_id} not found",
                source="json"
            )
        
        del all_data[entity_id]
        
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON after deletion",
            source="json"
        )
    
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the JSON file."""
        all_data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=entity_id in all_data,
            source="json"
        )