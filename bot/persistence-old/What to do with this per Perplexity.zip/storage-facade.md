"""
Data Storage Facade Layer for GOF2BountyBot

This module provides a clear interface between the bot and underlying storage mechanisms.
It abstracts away the details of data storage, allowing for a seamless transition from
JSON files to a SQL database.

The architecture follows these principles:
1. Clear separation between interface and implementation
2. Consistent patterns for all entity types
3. Support for both JSON and future SQL storage
4. Gradual migration path from JSON to SQL

Classes:
- StorageFacade: Main entry point for all data operations
- Repository: Base interface for entity-specific repositories
- JSONRepository: JSON file implementation of Repository
- SQLRepository: SQL database implementation of Repository (to be implemented later)
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union, cast

import json
import logging
import os
import aiofiles

# Set up logging
logger = logging.getLogger('storage_facade')

# Generic type variable for entities
T = TypeVar('T')


class StorageResult:
    """Represents the result of a storage operation.
    
    This class provides a consistent way to return results from storage operations,
    including success/failure status, error messages, and the data itself.
    """
    
    def __init__(self, 
                 success: bool, 
                 data: Any = None, 
                 error: Optional[str] = None,
                 source: str = "unknown"):
        """Initialize a new StorageResult.
        
        Args:
            success: Whether the operation was successful
            data: The data returned by the operation (if any)
            error: Error message if the operation failed
            source: The source of the data (e.g., "json", "sql")
        """
        self.success = success
        self.data = data
        self.error = error
        self.source = source
    
    def __bool__(self) -> bool:
        """Allow StorageResult to be used in boolean context."""
        return self.success


class Repository(Generic[T], ABC):
    """Base interface for all repositories.
    
    A repository is responsible for storing and retrieving entities of a specific type.
    This abstract base class defines the interface that all repository implementations
    must follow.
    """
    
    @abstractmethod
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID.
        
        Args:
            entity_id: The unique identifier of the entity to retrieve
            
        Returns:
            StorageResult containing the entity if found
        """
        pass
    
    @abstractmethod
    async def get_all(self) -> StorageResult:
        """Retrieve all entities in the repository.
        
        Returns:
            StorageResult containing a list of all entities
        """
        pass
    
    @abstractmethod
    async def save(self, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the repository.
        
        Args:
            entity_id: The unique identifier of the entity
            data: The entity data to save
            
        Returns:
            StorageResult indicating success or failure
        """
        pass
    
    @abstractmethod
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the repository.
        
        Args:
            entity_id: The unique identifier of the entity to delete
            
        Returns:
            StorageResult indicating success or failure
        """
        pass
    
    @abstractmethod
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the repository.
        
        Args:
            entity_id: The unique identifier of the entity to check
            
        Returns:
            StorageResult with data=True if the entity exists, data=False otherwise
        """
        pass


class JSONRepository(Repository[T]):
    """JSON file implementation of Repository.
    
    This class implements the Repository interface using JSON files as the storage mechanism.
    Each entity type is stored in a separate JSON file.
    """
    
    def __init__(self, file_path: Union[str, Path]):
        """Initialize a new JSONRepository.
        
        Args:
            file_path: Path to the JSON file that stores the entities
        """
        self.file_path = Path(file_path)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        
    async def _load_data(self) -> Dict[str, Any]:
        """Load data from the JSON file.
        
        Returns:
            Dictionary containing the data from the JSON file
        """
        if not self.file_path.exists():
            return {}
        
        try:
            async with aiofiles.open(self.file_path, 'r') as f:
                content = await f.read()
                return json.loads(content) if content.strip() else {}
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading JSON from {self.file_path}: {e}")
            return {}
    
    async def _save_data(self, data: Dict[str, Any]) -> bool:
        """Save data to the JSON file.
        
        Args:
            data: Dictionary containing the data to save
            
        Returns:
            True if the save was successful, False otherwise
        """
        try:
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            
            async with aiofiles.open(self.file_path, 'w') as f:
                await f.write(json.dumps(data, indent=2))
            
            return True
        except IOError as e:
            logger.error(f"Error saving to JSON {self.file_path}: {e}")
            return False
    
    async def get(self, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID from the JSON file.
        
        Args:
            entity_id: The unique identifier of the entity to retrieve
            
        Returns:
            StorageResult containing the entity if found
        """
        data = await self._load_data()
        
        if entity_id in data:
            return StorageResult(
                success=True,
                data=data[entity_id],
                source="json"
            )
        
        return StorageResult(
            success=False,
            error=f"Entity {entity_id} not found",
            source="json"
        )
    
    async def get_all(self) -> StorageResult:
        """Retrieve all entities from the JSON file.
        
        Returns:
            StorageResult containing a list of all entities
        """
        data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=list(data.values()),
            source="json"
        )
    
    async def save(self, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity to the JSON file.
        
        Args:
            entity_id: The unique identifier of the entity
            data: The entity data to save
            
        Returns:
            StorageResult indicating success or failure
        """
        all_data = await self._load_data()
        
        # Ensure ID is set in data
        data["id"] = entity_id
        
        # Update with new data
        all_data[entity_id] = data
        
        # Save back to file
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                data=data,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON",
            source="json"
        )
    
    async def delete(self, entity_id: str) -> StorageResult:
        """Delete an entity from the JSON file.
        
        Args:
            entity_id: The unique identifier of the entity to delete
            
        Returns:
            StorageResult indicating success or failure
        """
        all_data = await self._load_data()
        
        if entity_id not in all_data:
            return StorageResult(
                success=False,
                error=f"Entity {entity_id} not found",
                source="json"
            )
        
        del all_data[entity_id]
        
        success = await self._save_data(all_data)
        
        if success:
            return StorageResult(
                success=True,
                source="json"
            )
        
        return StorageResult(
            success=False,
            error="Failed to save to JSON after deletion",
            source="json"
        )
    
    async def exists(self, entity_id: str) -> StorageResult:
        """Check if an entity exists in the JSON file.
        
        Args:
            entity_id: The unique identifier of the entity to check
            
        Returns:
            StorageResult with data=True if the entity exists, data=False otherwise
        """
        all_data = await self._load_data()
        
        return StorageResult(
            success=True,
            data=entity_id in all_data,
            source="json"
        )


class EntityType(Enum):
    """Enum representing the different types of entities in the system."""
    USER = auto()
    GUILD = auto()
    BOUNTY = auto()
    REACTION_MENU = auto()
    GAME_DATA = auto()


class StorageFacade:
    """Main entry point for all data storage operations.
    
    This class provides a unified interface for all data storage operations,
    regardless of the underlying storage mechanism.
    """
    
    def __init__(self, data_dir: str = "data"):
        """Initialize a new StorageFacade.
        
        Args:
            data_dir: Directory where data files are stored
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize repositories for each entity type
        self._repositories: Dict[EntityType, Repository] = {
            EntityType.USER: JSONRepository(self.data_dir / "users.json"),
            EntityType.GUILD: JSONRepository(self.data_dir / "guilds.json"),
            EntityType.BOUNTY: JSONRepository(self.data_dir / "bounties.json"),
            EntityType.REACTION_MENU: JSONRepository(self.data_dir / "reaction_menus.json"),
            EntityType.GAME_DATA: JSONRepository(self.data_dir / "game_data.json")
        }
    
    def get_repository(self, entity_type: EntityType) -> Repository:
        """Get the repository for a specific entity type.
        
        Args:
            entity_type: The type of entity to get the repository for
            
        Returns:
            The repository for the specified entity type
        """
        return self._repositories[entity_type]
    
    async def get_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID.
        
        Args:
            entity_type: The type of entity to retrieve
            entity_id: The unique identifier of the entity to retrieve
            
        Returns:
            StorageResult containing the entity if found
        """
        return await self.get_repository(entity_type).get(entity_id)
    
    async def get_all_entities(self, entity_type: EntityType) -> StorageResult:
        """Retrieve all entities of a specific type.
        
        Args:
            entity_type: The type of entities to retrieve
            
        Returns:
            StorageResult containing a list of all entities of the specified type
        """
        return await self.get_repository(entity_type).get_all()
    
    async def save_entity(self, entity_type: EntityType, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity.
        
        Args:
            entity_type: The type of entity to save
            entity_id: The unique identifier of the entity
            data: The entity data to save
            
        Returns:
            StorageResult indicating success or failure
        """
        return await self.get_repository(entity_type).save(entity_id, data)
    
    async def delete_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Delete an entity.
        
        Args:
            entity_type: The type of entity to delete
            entity_id: The unique identifier of the entity to delete
            
        Returns:
            StorageResult indicating success or failure
        """
        return await self.get_repository(entity_type).delete(entity_id)
    
    async def entity_exists(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Check if an entity exists.
        
        Args:
            entity_type: The type of entity to check
            entity_id: The unique identifier of the entity to check
            
        Returns:
            StorageResult with data=True if the entity exists, data=False otherwise
        """
        return await self.get_repository(entity_type).exists(entity_id)