"""
High-level adapters for specific entity types

These adapters provide entity-specific methods that build on top of the base repository interface.
They implement the business logic and provide convenience methods for working with specific entities.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional

from .facade import StorageResult
from .repositories import Repository


class BaseAdapter:
    """Base class for all adapters."""
    
    def __init__(self, repository: Repository):
        self.repository = repository


class UserAdapter(BaseAdapter):
    """Adapter for user entities.
    
    Provides user-specific operations like credit management, inventory operations, etc.
    """
    
    async def get_user(self, user_id: str) -> StorageResult:
        """Get a user by ID."""
        return await self.repository.get(user_id)
    
    async def save_user(self, user_id: str, user_data: Dict[str, Any]) -> StorageResult:
        """Save user data."""
        return await self.repository.save(user_id, user_data)
    
    async def create_user(self, user_id: str, username: Optional[str] = None) -> StorageResult:
        """Create a new user with default values."""
        default_user = {
            "id": user_id,
            "username": username,
            "credits": 0,
            "reputation": 0,
            "inventory": {},
            "settings": {},
            "lifetimeBountyCreditsWon": 0,
            "bountyCooldownEnd": -1.0,
            "systemsChecked": 0,
            "bountyWins": 0,
            "duelWins": 0,
            "duelLosses": 0,
            "duelCreditsWins": 0,
            "duelCreditsLosses": 0,
            "homeGuildID": -1,
            "prestiges": 0,
            "alerts": {},
            "classicModeEnabled": False
        }
        
        return await self.repository.save(user_id, default_user)
    
    async def get_or_create_user(self, user_id: str, username: Optional[str] = None) -> StorageResult:
        """Get a user or create it if it doesn't exist."""
        result = await self.get_user(user_id)
        
        if result.success:
            return result
        
        # User doesn't exist, create it
        return await self.create_user(user_id, username)
    
    async def update_user_credits(self, user_id: str, amount: int) -> StorageResult:
        """Update user credits by the specified amount."""
        result = await self.get_or_create_user(user_id)
        
        if not result.success:
            return result
        
        user_data = result.data
        user_data["credits"] = user_data.get("credits", 0) + amount
        
        return await self.save_user(user_id, user_data)
    
    async def get_user_credits(self, user_id: str) -> StorageResult:
        """Get user credits (returns 0 if user doesn't exist)."""
        result = await self.get_user(user_id)
        
        if result.success:
            credits = result.data.get("credits", 0)
            return StorageResult(success=True, data=credits, source=result.source)
        
        return StorageResult(success=True, data=0, source="default")
    
    async def set_user_home_guild(self, user_id: str, guild_id: str) -> StorageResult:
        """Set the user's home guild."""
        result = await self.get_or_create_user(user_id)
        
        if not result.success:
            return result
        
        user_data = result.data
        user_data["homeGuildID"] = int(guild_id) if guild_id.isdigit() else guild_id
        
        return await self.save_user(user_id, user_data)


class GuildAdapter(BaseAdapter):
    """Adapter for guild entities.
    
    Provides guild-specific operations like channel management, settings, etc.
    """
    
    async def get_guild(self, guild_id: str) -> StorageResult:
        """Get a guild by ID."""
        return await self.repository.get(guild_id)
    
    async def save_guild(self, guild_id: str, guild_data: Dict[str, Any]) -> StorageResult:
        """Save guild data."""
        return await self.repository.save(guild_id, guild_data)
    
    async def create_guild(self, guild_id: str, name: str) -> StorageResult:
        """Create a new guild with default settings."""
        default_guild = {
            "id": guild_id,
            "name": name,
            "settings": {},
            "prefix": "!",
            "enabled_modules": [],
            "admin_roles": [],
            "bountiesDisabled": False,
            "shopsDisabled": False,
            "alertRoles": {},
            "guildChannels": {}
        }
        
        return await self.repository.save(guild_id, default_guild)
    
    async def get_or_create_guild(self, guild_id: str, name: str) -> StorageResult:
        """Get a guild or create it if it doesn't exist."""
        result = await self.get_guild(guild_id)
        
        if result.success:
            return result
        
        # Guild doesn't exist, create it
        return await self.create_guild(guild_id, name)
    
    async def set_guild_prefix(self, guild_id: str, prefix: str) -> StorageResult:
        """Set the guild's command prefix."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        guild_data["prefix"] = prefix
        
        return await self.save_guild(guild_id, guild_data)
    
    async def get_guild_prefix(self, guild_id: str) -> StorageResult:
        """Get guild prefix (returns default if guild doesn't exist)."""
        result = await self.get_guild(guild_id)
        
        if result.success:
            prefix = result.data.get("prefix", "!")
            return StorageResult(success=True, data=prefix, source=result.source)
        
        return StorageResult(success=True, data="!", source="default")
    
    async def enable_module(self, guild_id: str, module_name: str) -> StorageResult:
        """Enable a module for the guild."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        enabled_modules = guild_data.get("enabled_modules", [])
        
        if module_name not in enabled_modules:
            enabled_modules.append(module_name)
            guild_data["enabled_modules"] = enabled_modules
        
        return await self.save_guild(guild_id, guild_data)
    
    async def disable_module(self, guild_id: str, module_name: str) -> StorageResult:
        """Disable a module for the guild."""
        result = await self.get_guild(guild_id)
        
        if not result.success:
            return StorageResult(success=False, error="Guild not found")
        
        guild_data = result.data
        enabled_modules = guild_data.get("enabled_modules", [])
        
        if module_name in enabled_modules:
            enabled_modules.remove(module_name)
            guild_data["enabled_modules"] = enabled_modules
        
        return await self.save_guild(guild_id, guild_data)


class BountyAdapter(BaseAdapter):
    """Adapter for bounty entities.
    
    Provides bounty-specific operations like searching, filtering, etc.
    """
    
    async def get_bounty(self, bounty_id: str) -> StorageResult:
        """Get a bounty by ID."""
        return await self.repository.get(bounty_id)
    
    async def save_bounty(self, bounty_id: str, bounty_data: Dict[str, Any]) -> StorageResult:
        """Save bounty data."""
        return await self.repository.save(bounty_id, bounty_data)
    
    async def get_open_bounties(self, guild_id: str) -> StorageResult:
        """Get all open bounties for a guild."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        open_bounties = [
            bounty for bounty in result.data
            if bounty.get("guild_id") == guild_id and bounty.get("status") == "open"
        ]
        
        return StorageResult(
            success=True,
            data=open_bounties,
            source=result.source
        )
    
    async def get_bounties_by_status(self, status: str) -> StorageResult:
        """Get all bounties with a specific status."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        filtered_bounties = [
            bounty for bounty in result.data
            if bounty.get("status") == status
        ]
        
        return StorageResult(
            success=True,
            data=filtered_bounties,
            source=result.source
        )


class ReactionMenuAdapter(BaseAdapter):
    """Adapter for reaction menu entities.
    
    Provides reaction menu-specific operations.
    """
    
    async def get_reaction_menu(self, menu_id: str) -> StorageResult:
        """Get a reaction menu by ID."""
        return await self.repository.get(menu_id)
    
    async def save_reaction_menu(self, menu_id: str, menu_data: Dict[str, Any]) -> StorageResult:
        """Save reaction menu data."""
        return await self.repository.save(menu_id, menu_data)
    
    async def get_active_menus(self) -> StorageResult:
        """Get all active reaction menus."""
        result = await self.repository.get_all()
        
        if not result.success:
            return result
        
        active_menus = [
            menu for menu in result.data
            if menu.get("active", False)
        ]
        
        return StorageResult(
            success=True,
            data=active_menus,
            source=result.source
        )