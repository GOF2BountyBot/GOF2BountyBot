"""
Main Storage Facade Implementation

This module contains the primary StorageFacade class that serves as the 
main entry point for all data storage operations in the bot.
"""

from __future__ import annotations
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, Optional

from .repositories import Repository, JSONRepository
from .adapters import UserAdapter, GuildAdapter, BountyAdapter, ReactionMenuAdapter


class StorageResult:
    """Represents the result of a storage operation."""
    
    def __init__(self, 
                 success: bool, 
                 data: Any = None, 
                 error: Optional[str] = None,
                 source: str = "unknown"):
        self.success = success
        self.data = data
        self.error = error
        self.source = source
    
    def __bool__(self) -> bool:
        """Allow StorageResult to be used in boolean context."""
        return self.success


class EntityType(Enum):
    """Enum representing the different types of entities in the system."""
    USER = auto()
    GUILD = auto()
    BOUNTY = auto()
    REACTION_MENU = auto()
    GAME_DATA = auto()


class StorageFacade:
    """Main entry point for all data storage operations.
    
    This class provides a unified interface for all data storage operations,
    regardless of the underlying storage mechanism.
    """
    
    def __init__(self, data_dir: str = "data"):
        """Initialize a new StorageFacade.
        
        Args:
            data_dir: Directory where data files are stored
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize repositories for each entity type
        self._repositories: Dict[EntityType, Repository] = {
            EntityType.USER: JSONRepository(self.data_dir / "users.json"),
            EntityType.GUILD: JSONRepository(self.data_dir / "guilds.json"),
            EntityType.BOUNTY: JSONRepository(self.data_dir / "bounties.json"),
            EntityType.REACTION_MENU: JSONRepository(self.data_dir / "reaction_menus.json"),
            EntityType.GAME_DATA: JSONRepository(self.data_dir / "game_data.json")
        }
        
        # Initialize adapters for high-level operations
        self.users = UserAdapter(self._repositories[EntityType.USER])
        self.guilds = GuildAdapter(self._repositories[EntityType.GUILD])
        self.bounties = BountyAdapter(self._repositories[EntityType.BOUNTY])
        self.reaction_menus = ReactionMenuAdapter(self._repositories[EntityType.REACTION_MENU])
    
    def get_repository(self, entity_type: EntityType) -> Repository:
        """Get the repository for a specific entity type."""
        return self._repositories[entity_type]
    
    async def get_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Retrieve an entity by ID."""
        return await self.get_repository(entity_type).get(entity_id)
    
    async def get_all_entities(self, entity_type: EntityType) -> StorageResult:
        """Retrieve all entities of a specific type."""
        return await self.get_repository(entity_type).get_all()
    
    async def save_entity(self, entity_type: EntityType, entity_id: str, data: Dict[str, Any]) -> StorageResult:
        """Save an entity."""
        return await self.get_repository(entity_type).save(entity_id, data)
    
    async def delete_entity(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Delete an entity."""
        return await self.get_repository(entity_type).delete(entity_id)
    
    async def entity_exists(self, entity_type: EntityType, entity_id: str) -> StorageResult:
        """Check if an entity exists."""
        return await self.get_repository(entity_type).exists(entity_id)
    
    # Convenience methods for specific entity types
    async def get_user(self, user_id: str) -> StorageResult:
        """Get a user by ID."""
        return await self.users.get_user(user_id)
    
    async def save_user(self, user_id: str, user_data: Dict[str, Any]) -> StorageResult:
        """Save user data."""
        return await self.users.save_user(user_id, user_data)
    
    async def get_guild(self, guild_id: str) -> StorageResult:
        """Get a guild by ID."""
        return await self.guilds.get_guild(guild_id)
    
    async def save_guild(self, guild_id: str, guild_data: Dict[str, Any]) -> StorageResult:
        """Save guild data."""
        return await self.guilds.save_guild(guild_id, guild_data)
    
    async def get_bounty(self, bounty_id: str) -> StorageResult:
        """Get a bounty by ID."""
        return await self.bounties.get_bounty(bounty_id)
    
    async def save_bounty(self, bounty_id: str, bounty_data: Dict[str, Any]) -> StorageResult:
        """Save bounty data."""
        return await self.bounties.save_bounty(bounty_id, bounty_data)