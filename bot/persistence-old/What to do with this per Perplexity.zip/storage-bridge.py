"""
Storage Bridge Module

This module provides compatibility functions to help transition from the old
database classes to the new facade layer without breaking existing code.

This acts as a drop-in replacement for the existing UserDB and GuildDB classes,
allowing you to gradually migrate your codebase to use the new facade layer.
"""

from typing import Any, Dict, Optional, Union
import asyncio

# This will be set when the facade is initialized
_storage_facade = None


def set_storage_facade(facade):
    """Set the storage facade instance to be used by the bridge."""
    global _storage_facade
    _storage_facade = facade


class UserDBBridge:
    """Bridge class to replace UserDB functionality with facade layer."""
    
    @property
    def facade(self):
        """Get the storage facade instance."""
        if _storage_facade is None:
            raise RuntimeError("Storage facade not initialized. Call set_storage_facade() first.")
        return _storage_facade
    
    async def getUser(self, userID: int):
        """Get user data (replacement for UserDB.getUser)."""
        result = await self.facade.get_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    def getUser_sync(self, userID: int):
        """Synchronous wrapper for getUser (for backward compatibility)."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.getUser(userID))
    
    async def idExists(self, userID: int) -> bool:
        """Check if user exists."""
        result = await self.facade.entity_exists(self.facade.EntityType.USER, str(userID))
        return result.data if result.success else False
    
    def idExists_sync(self, userID: int) -> bool:
        """Synchronous wrapper for idExists."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.idExists(userID))
    
    async def addID(self, userID: int):
        """Add a new user with default values."""
        result = await self.facade.users.create_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    def addID_sync(self, userID: int):
        """Synchronous wrapper for addID."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.addID(userID))
    
    async def getOrAddID(self, userID: int):
        """Get user or create if it doesn't exist."""
        result = await self.facade.users.get_or_create_user(str(userID))
        if result.success:
            return self._create_user_object(result.data)
        return None
    
    def getOrAddID_sync(self, userID: int):
        """Synchronous wrapper for getOrAddID."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.getOrAddID(userID))
    
    async def removeID(self, userID: int) -> bool:
        """Remove user."""
        result = await self.facade.delete_entity(self.facade.EntityType.USER, str(userID))
        return result.success
    
    def removeID_sync(self, userID: int) -> bool:
        """Synchronous wrapper for removeID."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.removeID(userID))
    
    def _create_user_object(self, user_data: Dict[str, Any]):
        """Create a user object from the data."""
        class UserObject:
            def __init__(self, data):
                # Copy all data as attributes
                for key, value in data.items():
                    setattr(self, key, value)
                
                # Ensure id is an integer
                self.id = int(data.get('id', 0))
                
                # Set up commonly used attributes with defaults
                self.credits = data.get('credits', 0)
                self.lifetimeBountyCreditsWon = data.get('lifetimeBountyCreditsWon', 0)
                self.bountyCooldownEnd = data.get('bountyCooldownEnd', -1.0)
                self.systemsChecked = data.get('systemsChecked', 0)
                self.bountyWins = data.get('bountyWins', 0)
                self.homeGuildID = data.get('homeGuildID', -1)
                self.prestiges = data.get('prestiges', 0)
                
            async def save(self):
                """Save this user's data back to storage."""
                user_data = {key: value for key, value in self.__dict__.items() if not key.startswith('_')}
                result = await _storage_facade.save_user(str(self.id), user_data)
                return result.success
            
            def save_sync(self):
                """Synchronous wrapper for save."""
                loop = asyncio.get_event_loop()
                return loop.run_until_complete(self.save())
        
        return UserObject(user_data)


class GuildDBBridge:
    """Bridge class to replace GuildDB functionality with facade layer."""
    
    @property
    def facade(self):
        """Get the storage facade instance."""
        if _storage_facade is None:
            raise RuntimeError("Storage facade not initialized. Call set_storage_facade() first.")
        return _storage_facade
    
    async def getGuild(self, guildID: int):
        """Get guild data."""
        result = await self.facade.get_guild(str(guildID))
        if result.success:
            return self._create_guild_object(result.data)
        return None
    
    def getGuild_sync(self, guildID: int):
        """Synchronous wrapper for getGuild."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.getGuild(guildID))
    
    async def idExists(self, guildID: int) -> bool:
        """Check if guild exists."""
        result = await self.facade.entity_exists(self.facade.EntityType.GUILD, str(guildID))
        return result.data if result.success else False
    
    def idExists_sync(self, guildID: int) -> bool:
        """Synchronous wrapper for idExists."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.idExists(guildID))
    
    async def addDcGuild(self, dcGuild):
        """Add a Discord guild."""
        result = await self.facade.guilds.create_guild(str(dcGuild.id), dcGuild.name)
        if result.success:
            return self._create_guild_object(result.data)
        return None
    
    def addDcGuild_sync(self, dcGuild):
        """Synchronous wrapper for addDcGuild."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.addDcGuild(dcGuild))
    
    async def removeID(self, guildID: int) -> bool:
        """Remove guild."""
        result = await self.facade.delete_entity(self.facade.EntityType.GUILD, str(guildID))
        return result.success
    
    def removeID_sync(self, guildID: int) -> bool:
        """Synchronous wrapper for removeID."""
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.removeID(guildID))
    
    def _create_guild_object(self, guild_data: Dict[str, Any]):
        """Create a guild object from the data."""
        class GuildObject:
            def __init__(self, data):
                # Copy all data as attributes
                for key, value in data.items():
                    setattr(self, key, value)
                
                # Ensure id is an integer
                self.id = int(data.get('id', 0))
                
                # Set up commonly used attributes with defaults
                self.name = data.get('name', '')
                self.prefix = data.get('prefix', '!')
                self.bountiesDisabled = data.get('bountiesDisabled', False)
                self.shopsDisabled = data.get('shopsDisabled', False)
                self.settings = data.get('settings', {})
            
            async def save(self):
                """Save this guild's data back to storage."""
                guild_data = {key: value for key, value in self.__dict__.items() if not key.startswith('_')}
                result = await _storage_facade.save_guild(str(self.id), guild_data)
                return result.success
            
            def save_sync(self):
                """Synchronous wrapper for save."""
                loop = asyncio.get_event_loop()
                return loop.run_until_complete(self.save())
        
        return GuildObject(guild_data)


# Create global instances that can be used as drop-in replacements
usersDB = UserDBBridge()
guildsDB = GuildDBBridge()


# Helper function to initialize the bridge
def initialize_storage_bridge(facade):
    """Initialize the storage bridge with a facade instance."""
    set_storage_facade(facade)
    return usersDB, guildsDB