"""
Configuration for the Storage Facade Layer

This module provides configuration options and setup utilities for the facade layer.
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional
import os


class StorageConfig:
    """Configuration for the storage facade layer."""
    
    def __init__(self, 
                 data_dir: str = "data",
                 backup_enabled: bool = True,
                 backup_dir: Optional[str] = None,
                 auto_migration: bool = False):
        """Initialize storage configuration.
        
        Args:
            data_dir: Directory where data files are stored
            backup_enabled: Whether to create backups before migrations
            backup_dir: Directory for backups (defaults to data_dir/backups)
            auto_migration: Whether to automatically migrate legacy data
        """
        self.data_dir = Path(data_dir)
        self.backup_enabled = backup_enabled
        self.backup_dir = Path(backup_dir) if backup_dir else self.data_dir / "backups"
        self.auto_migration = auto_migration
        
        # Ensure directories exist
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if backup_enabled:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def from_env(cls) -> 'StorageConfig':
        """Create configuration from environment variables."""
        return cls(
            data_dir=os.getenv("BOT_DATA_DIR", "data"),
            backup_enabled=os.getenv("BOT_BACKUP_ENABLED", "true").lower() == "true",
            backup_dir=os.getenv("BOT_BACKUP_DIR"),
            auto_migration=os.getenv("BOT_AUTO_MIGRATION", "false").lower() == "true"
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "data_dir": str(self.data_dir),
            "backup_enabled": self.backup_enabled,
            "backup_dir": str(self.backup_dir),
            "auto_migration": self.auto_migration
        }


def setup_storage_facade(config: Optional[StorageConfig] = None) -> 'StorageFacade':
    """Set up and return a configured StorageFacade instance.
    
    Args:
        config: Storage configuration. If None, uses default configuration.
        
    Returns:
        Configured StorageFacade instance
    """
    from .facade import StorageFacade
    
    if config is None:
        config = StorageConfig()
    
    return StorageFacade(data_dir=str(config.data_dir))


def setup_with_migration(legacy_data_dir: str = "data", 
                        new_data_dir: str = "data_new") -> 'StorageFacade':
    """Set up facade and migrate data from legacy format.
    
    Args:
        legacy_data_dir: Directory containing legacy data files
        new_data_dir: Directory for new facade data files
        
    Returns:
        Configured StorageFacade instance with migrated data
    """
    from .facade import StorageFacade
    from .migration import DataMigrator
    
    # Create facade with new data directory
    facade = StorageFacade(data_dir=new_data_dir)
    
    # Set up migrator
    migrator = DataMigrator(facade, legacy_data_dir)
    
    return facade, migrator